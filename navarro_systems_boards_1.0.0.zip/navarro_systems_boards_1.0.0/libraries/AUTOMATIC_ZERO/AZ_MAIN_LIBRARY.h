// LIBRARY ONLY VALID FOR "AZ BASE V1.5" AND NEXT

#ifndef AZ_MAIN_LIBRARY_H
#define AZ_MAIN_LIBRARY_H

// Libraries included ///
// IDE oficial
#include <Arduino.h>
#include <Wire.h>
#include <Servo.h>
// Extra
#include <Adafruit_NeoPixel.h>
#include <HX711.h>
#include <DFPlayerMini_Fast.h>
#include <ArduinoModbus.h>
#include <SparkFunESP8266WiFi.h>
#include <DRV8825.h>

////////////////START OF USER CONFIGURATION//////

// MAIN //
// General
#define FIRST_CRITICAL_ERROR_NUMBER 10
#define I2C_MODULE_INITIAL_ADDRESS 1

// Delays definition
#define GENERAL_TASK_PERIOD 25 // Millis
#define INIT_MIN_DELAY 5000 // Millis

// ONLY FOR RS485
#define MODBUS_LAYER // Uncomment for enabling modbus layer

// ONLY FOR STEPPER // Acceleration and deceleration values are always in FULL steps / s^2
#define MOTOR_STEPS 200
#define RPM 120
#define MOTOR_ACCEL 1000
#define MOTOR_DECEL 1000

// ONLY FOR DIGITAL I/O


// LANGUAGES //
#define SPANISH_LANGUAGE
//#define ENGLISH_LANGUAGE

////////////END OF USER CONFIGURATION///////////

// Debug stuff
//#define DEBUG
#define DEBUG_DELAY 50000 // Micros

#define T0 0
#define T1 1
#define T2 2
#define T3 3
#define T4 4
#define T5 5
#define T6 6
#define T7 7
#define T8 8
#define T9 9
#define T10 10
#define T11 11
#define T12 12
#define T13 13
#define T14 14
#define T15 15
#define T16 16
#define COM1 17
#define COM2 18

#define PIN_STEP PIN_GPIO1
#define PIN_DIR PIN_GPIO2

// Serial ports
#if defined(ARDUINO_SAMD_ZERO) && defined(SERIAL_PORT_USBVIRTUAL) // Required for Serial on Zero based boards
#define Serial SERIAL_PORT_USBVIRTUAL
#endif
#define SERIAL_PC_PORT Serial
#define SERIAL_PC_PORT_BAUD 115200
#define SERIAL_COM_PLUGIN_PORT Serial5
#define SERIAL_COM_PLUGIN_PORT_BAUD 9600
#define SERIAL_FUNC_PLUGIN_PORT Serial1
#define SERIAL_FUNC_PLUGIN_PORT_BAUD 9600

// I2C ports
#define BUS_I2C Wire
#define PLUGIN_I2C Wire1
#define I2C_MODULE_SETUP_ADDRESS 80

// FUNCTIONS ///

// CONFIG FUNCTIONS
void az_setup (void);
void az_run (void);

// SYSTEM FUNCTIONS

int8_t indexed_functions (uint8_t function_index, uint8_t pin, uint8_t command = 0, uint8_t per1_val0 = 0);
int8_t get_power_plugin (uint8_t module = 0, bool update = 0); // Function index: 5
int8_t get_com_plugin (uint8_t module = 0, bool update = 0); // Function index: 6
int8_t get_func_plugin (uint8_t module = 0, bool update = 0); // Function index: 7
uint8_t get_module_qty (void);
void led_set (int color);
float bat_voltage_read (void);
void wifi_credentials_set (char* ssid, char* password);

// FUNC FUNCTIONS
int8_t az_digital_write (uint8_t module, uint8_t pin, bool command); // Function index: 1
int8_t az_digital_read (uint8_t module, uint8_t pin); // Function index: 2
int8_t az_analog_write (uint8_t module, uint8_t pin, int32_t command, bool percentage1_or_value0 = 0); // Function index: 3
int32_t az_analog_read (uint8_t module, uint8_t pin, bool percentage1_or_value0 = 0); // Function index: 4

int8_t az_read_temperature (uint8_t module);

int8_t az_relay_switch (uint8_t module, uint8_t relay, bool command);
int8_t az_relay_state (uint8_t module, uint8_t relay);

int8_t az_dcmotor_max_move (uint8_t module, uint8_t motor, bool command, bool direction);
int8_t az_dcmotor_half_bridge_state (uint8_t module, uint8_t motor, bool half_bridge);
int8_t az_dcmotor_set_speed (uint8_t module, uint8_t motor, uint8_t speed, bool direction);
int8_t az_dcmotor_power_read (uint8_t module, uint8_t motor);

int8_t az_stmotor_step_control (uint8_t module, uint8_t motor, bool command);
int8_t az_stmotor_dir_control (uint8_t module, uint8_t motor, bool command);
int8_t az_stmotor_fault_state (uint8_t module, uint8_t motor);
int32_t az_stmotor_move_state (uint8_t module, uint8_t motor);
int8_t az_stmotor_set_rpm_speed (uint8_t module, uint8_t motor, uint32_t rpm_speed, bool direction);
int8_t az_stmotor_move_degrees (uint8_t module, uint8_t motor, uint32_t degrees, bool direction, uint32_t time_to_accomplish_ms);

int8_t az_servo_set_degrees (uint8_t module, uint8_t servo, int32_t command);

int32_t az_power_measure_read (uint8_t module, uint8_t coil);

int8_t az_audio_stop (uint8_t module);
int8_t az_audio_play_track (uint8_t module, uint16_t track, int32_t command);
int8_t az_audio_get_current_track (uint8_t module, uint8_t servo, int32_t command);

int32_t az_load_cell_read (uint8_t module, uint8_t cell);

#endif