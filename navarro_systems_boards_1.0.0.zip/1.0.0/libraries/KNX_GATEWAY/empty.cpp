// LIBRARY FOR SHOWING EXAMPLES

// Libraries included
#include "empty.h"