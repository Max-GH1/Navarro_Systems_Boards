// LIBRARY ONLY VALID FOR "AZ BASE V1.5"

// Libraries included
#include "AZ_MAIN_LIBRARY.h"

// Plugins name

String power_plugins_name[] = {"NO", "DC-DC PLUGIN", "BAT PLUGIN"};
String com_plugins_name[] = {"NO", "RS-485 PLUGIN", "KNX PLUGIN", "WIFI+BLE PLUGIN", "WIFI PLUGIN", "ETHERNET PLUGIN", "LORA PLUGIN"};
String func_plugins_name[] = {"NO", "RELAY PLUGIN", "DC MOTOR PLUGIN", "STEPPER MOTOR PLUGIN", "RC SERVO PLUGIN", "DIGITAL IN/OUT PLUGIN", "ANALOG IN/OUT PLUGIN", "0-20mA IN/OUT PLUGIN", "POWER MEASURE PLUGIN", "AUDIO PLUGIN", "DIRECT GPIO PLUGIN", "LOAD CELL PLUGIN"};

// Languages

#if defined(SPANISH_LANGUAGE)
#define INIT_START "COMENZANDO INICIALIZACIÓN..."
#define INIT_WORKING "CONTINUANDO INICIALIZACIÓN..."
#define INIT_FINISH_OK "...INICIALIZACIÓN COMPLETADA"
#define INIT_FINISH_BAD "...INICIALIZACIÓN FALLIDA"
#define CRITICAL_ERROR "ERROR CRÍTICO, BLOQUEANDO DISPOSITIVO..."
#define ERROR_CODE "Código de error"
#define PLUGIN_NOT_DETECTED "Plugin no detectado"
#define PLUGINS_DETECTED "Plugins propios detectados"
#define POWER_PLUGIN "Plugin de potencia"
#define COM_PLUGIN "Plugin de comunicaciones"
#define FUNC_PLUGIN "Plugin de funcionalidad"
#define SYSTEM_VOLTAGE_LEVEL "Voltaje del sistema"
#define MICRO_VOLTAGE_LEVEL "Voltaje del micro"
#define USB_CONNECTED "USB conectado"
#define USB_NOT_CONNECTED "USB no conectado"
#define MODULE_FOUND_IN_POSITION "Módulo hallado en posición"
#define NOT_ADDITIONAL_MODULES_DETECTED "No han sido hallados módulos adicionales"
#define WAITING_FOR_MASTER "Esperando al maestro..."
#define WAITING_FOR_ADDRESS_ASSIGN "Esperando asignación de dirección I2C..."
#define ADDRESS_OBTAINED "Dirección I2C asignada y reentrada al bus con esta: "
#define MODULE_FOUND "Módulo encontrado!"
#define IM_MASTER "Soy un módulo maestro"
#define IM_SLAVE "Vaya, soy un módulo esclavo..."
#define DONE "Hecho"
#define MODULE_PLUGIN_REGISTERING "Registrando los plugins del módulo"
#define MODULE_PLUGIN_REGISTERED "Registrados los plugins de todos los módulos"
#define I2C_ERROR_CODE "Código de error I2C"
#define INCOMING_MASTER_COM "Comunicación entrante del maestro..."
#define MASTER_DATA_RECEIVED "Datos recibidos del maestro"
#define FINISHED_MASTER_COM "Comunicación con el maestro finalizada"
#define WIFI_PLUGIN_COM_BAD "Error conectando al plugin WiFi"
#define WIFI_PLUGIN_COM_OK "Éxito conectando al plugin WiFi"
#define WIFI_PLUGIN_CONF_BAD "Error configurando el modo del plugin WiFi"
#define WIFI_PLUGIN_CONF_OK "Error configurando el modo del plugin WiFi"
#define CONNECTING_TO_WIFI_NETWORK "Conectando a la red WiFi"
#define WITH_PASSWORD "con la contraseña"
#define WIFI_NETWORK_CON_BAD "Error conectando a la red WiFi"
#define WIFI_NETWORK_CON_OK "Éxito conectando a la red WiFi"
#define WIFI_CREDENTIALS_NOT_FOUND "No han sido hallados credenciales WiFi en memoria"
#define EXECUTING_SLAVE_MODE "Ejecutando indefinidamente el modo esclavo"
#endif

#if defined(ENGLISH_LANGUAGE)
#define INIT_START "STARTING INITIALIZATION..."
#define INIT_WORKING "CONTINUING INITIALIZATION..."
#define INIT_FINISH_OK "...INITIALIZATION COMPLETED"
#define INIT_FINISH_BAD "...INITIALIZATION FAILED"
#define CRITICAL_ERROR "CRITICAL ERROR, BLOCKING DEVICE..."
#define ERROR_CODE "Error code"
#define PLUGIN_NOT_DETECTED "Plugin not detected"
#define PLUGINS_DETECTED "Plugins detected"
#define POWER_PLUGIN "Power plugin"
#define COM_PLUGIN "Communication plugin"
#define FUNC_PLUGIN "Functionality plugin"
#define SYSTEM_VOLTAGE_LEVEL "System voltage"
#define MICRO_VOLTAGE_LEVEL "Microcontroller voltage"
#define USB_CONNECTED "USB connected"
#define USB_NOT_CONNECTED "USB not connected"
#define MODULE_FOUND_IN_POSITION "Module found in position"
#define NOT_ADDITIONAL_MODULES_DETECTED "Not additional modules detected"
#define WAITING_FOR_MASTER "Waiting for master..."
#define WAITING_FOR_ADDRESS_ASSIGN "Waiting for I2C address assignation..."
#define ADDRESS_OBTAINED "I2C address assignated: "
#define MODULE_FOUND "Module found!"
#define IM_MASTER "I'm a master module"
#define IM_SLAVE "Ooops, I'm a slave module..."
#define DONE "Done"
#define MODULE_PLUGIN_REGISTERING "Registering plugins of module"
#define MODULE_PLUGIN_REGISTERED "Registered all plugins of all modules"
#define I2C_ERROR_CODE "I2C error code"
#define INCOMING_MASTER_COM "Incoming master communication..."
#define MASTER_DATA_RECEIVED "Master data received"
#define FINISHED_MASTER_COM "Finished master communication"
#define WIFI_PLUGIN_COM_BAD "Error connecting to WiFi plugin"
#define WIFI_PLUGIN_COM_OK "Success connecting to WiFi plugin"
#define WIFI_PLUGIN_CONF_BAD "Error setting WiFi plugin mode"
#define WIFI_PLUGIN_CONF_OK "Success setting WiFi plugin mode"
#define CONNECTING_TO_WIFI_NETWORK "Connecting to WiFi network"
#define WITH_PASSWORD "with password"
#define WIFI_NETWORK_CON_BAD "Error connecting to WiFi network"
#define WIFI_NETWORK_CON_OK "Success connecting to WiFi network"
#define WIFI_CREDENTIALS_NOT_FOUND "WiFi credentials not found in memory"
#define EXECUTING_SLAVE_MODE "Executing slave mode forever"
#endif

// Variables
static uint8_t error_code = 0;
static bool charging_stat = 0;
static bool usb_stat = 0;
static bool master0_or_slave1;
static int8_t last_indexed_function_result = 0;
static uint8_t module_list[100][4]; // [100 possible modules] [adress, power plugin, com plugin, func plugin]
static uint8_t knx_address[3];
static uint16_t stepper_working_time = 0;
static uint8_t com_plugin = 0;
static uint8_t power_plugin = 0;
static uint8_t func_plugin = 0;
static uint8_t module_qty = 0;
static Adafruit_NeoPixel strip(1, PIN_LED_RGB, NEO_WBRG + NEO_KHZ800);
static HX711 az_load_cell_plugin;
static DFPlayerMini_Fast az_audio_player_plugin;
static Servo S1, S2, S3, S4, S5, S6, S7, S8;
static DRV8825 stepper(MOTOR_STEPS, PIN_DIR, PIN_STEP);
static char WiFi_SSID[30] = "";
static char WiFi_Password[30] = "";


// FUNCTIONS

// System functions

bool unconnected_pin_detect (uint8_t pin) {

  float temp = 0;
  pinMode(pin, INPUT_PULLUP);
  delay(50);
  temp = analogRead(pin);
  pinMode(pin, INPUT_PULLDOWN);
  delay(50);
  temp = temp - analogRead(pin);
  pinMode(pin, INPUT);
  if (temp >= 500) {
    return 1;
  } else {
    return 0;
  }

}

void mux_out_select (uint8_t pin) {

 pin = pin-1;
 digitalWrite(PIN_MUX_S0, bitRead(pin, 0));
 digitalWrite(PIN_MUX_S1, bitRead(pin, 1));
 digitalWrite(PIN_MUX_S2, bitRead(pin, 2));

}

// I2C Slave functions

void receiveEvent(int howMany) {

  uint8_t function_index = 0, pin = 0, command = 0, per1_val0 = 0;

  SERIAL_PC_PORT.println(INCOMING_MASTER_COM);  //led_set(0xFF00FF);

  // while (!(BUS_I2C.available() == 4)) {
  // SERIAL_PC_PORT.println("Esperando todos los datos del maestro...");
  // }

  if (BUS_I2C.available()) {
  function_index = BUS_I2C.read();
  SERIAL_PC_PORT.println(function_index);
}
  if (BUS_I2C.available()) {
  pin = BUS_I2C.read();
  SERIAL_PC_PORT.println(pin);
}
  if (BUS_I2C.available()) {
  command = BUS_I2C.read();
  SERIAL_PC_PORT.println(command);
}
  if (BUS_I2C.available()) {
  per1_val0 = BUS_I2C.read();
  SERIAL_PC_PORT.println(per1_val0);
}

  while (BUS_I2C.available()) {
    BUS_I2C.read();
  }

  SERIAL_PC_PORT.println(MASTER_DATA_RECEIVED);

  if (error_code > FIRST_CRITICAL_ERROR_NUMBER) {

    return;
  } else {
    last_indexed_function_result = indexed_functions(function_index, pin, command, per1_val0);
  }

  SERIAL_PC_PORT.println(FINISHED_MASTER_COM);
}

void requestEvent() {

  //led_set(0xFF0000); // Blue
  if (error_code > FIRST_CRITICAL_ERROR_NUMBER) {
    return;
  } else {
  SERIAL_PC_PORT.println("El maestro pide resultado");
    BUS_I2C.write(last_indexed_function_result);
  SERIAL_PC_PORT.println("Y se entrega");
  }

}

int8_t get_power_plugin (uint8_t module, bool update) { // 5

  if (module > 0 && update) {

    BUS_I2C.beginTransmission(module);

    BUS_I2C.write(5);
    BUS_I2C.write(0);
    BUS_I2C.write(0);
    BUS_I2C.write(0);

    BUS_I2C.endTransmission();

    BUS_I2C.requestFrom(module, 1);
    module_list[module][1] = BUS_I2C.read();

  }

  return module_list[module][1];

}

int8_t get_com_plugin (uint8_t module, bool update) { // 6

  if (module > 0 && update) {

    BUS_I2C.beginTransmission(module);

    BUS_I2C.write(6);
    BUS_I2C.write(0);
    BUS_I2C.write(0);
    BUS_I2C.write(0);

    BUS_I2C.endTransmission();

    BUS_I2C.requestFrom(module, 1);
    module_list[module][2] = BUS_I2C.read();

  }

  return module_list[module][2];

}

int8_t get_func_plugin (uint8_t module, bool update) { // 7

  if (module > 0 && update) {

    BUS_I2C.beginTransmission(module);

    BUS_I2C.write(7);
    BUS_I2C.write(0);
    BUS_I2C.write(0);
    BUS_I2C.write(0);

    BUS_I2C.endTransmission();

    BUS_I2C.requestFrom(module, 1);
    module_list[module][3] = BUS_I2C.read();

  }

  return module_list[module][3];
}

void critical_error_check (void) { // Error codes above FIRST_CRITICAL_ERROR_NUMBER are criticals

  if (error_code >= FIRST_CRITICAL_ERROR_NUMBER) {
    SERIAL_PC_PORT.println(" ");
    SERIAL_PC_PORT.println(CRITICAL_ERROR);
    SERIAL_PC_PORT.print(ERROR_CODE);
    SERIAL_PC_PORT.print(": ");
    SERIAL_PC_PORT.println(error_code);
    while (1) {
      led_set(0x0000FF); // Red
      delay(1000);
      led_set(0x000000); // Off
      delay(1000);
    }
  }

}

float bat_voltage_read (void) {

  mux_out_select(MUX_BAT);
  pinMode(PIN_MUX_OUT, INPUT);
  return analogRead(PIN_MUX_OUT);

}

void led_set (int color) {

  strip.setPixelColor(0, color);
  strip.show();

}

void wifi_credentials_set (char* ssid, char* password) {

strcpy(WiFi_SSID, ssid);
strcpy(WiFi_Password, password);

}

// void knx_address_set (uint8_t bit2, uint8_t bit1, uint8_t bit0) {
//   knx_address[0] = bit0;
//   knx_address[1] = bit1;
//   knx_address[2] = bit2;
// }

void plugin_detection (void) {

  float temp = 0;
  delay(100);

  mux_out_select(MUX_COM_P);
  if (unconnected_pin_detect(PIN_MUX_OUT)) {
    com_plugin = 0;
  } else {
    temp = analogRead(PIN_MUX_OUT) / (20.48);
    com_plugin = temp + 0.5;
  }

  mux_out_select(MUX_POW_P);
  if (unconnected_pin_detect(PIN_MUX_OUT)) {
    power_plugin = 0;
  } else {
    temp = analogRead(PIN_MUX_OUT) / (20.48);
    power_plugin = temp + 0.5;
  }

  mux_out_select(MUX_FUN_P);
  if (unconnected_pin_detect(PIN_MUX_OUT)) {
    func_plugin = 0;
  } else {
    temp = analogRead(PIN_MUX_OUT) / (20.48);
    func_plugin = temp + 0.5;
  }

  module_list[0][0] = 0;
  module_list[0][1] = power_plugin;
  module_list[0][2] = com_plugin;
  module_list[0][3] = func_plugin;

}

void module_detection (void) {

  int i;

  digitalWrite(PIN_POST_MODULE, 1);
  delay(1000);

  for (i = I2C_MODULE_INITIAL_ADDRESS; i < 100 + I2C_MODULE_INITIAL_ADDRESS; i++) {
    delay(100);
    BUS_I2C.beginTransmission(I2C_MODULE_SETUP_ADDRESS);
    if (BUS_I2C.endTransmission() == 0) {
      SERIAL_PC_PORT.println(MODULE_FOUND);
      module_list[i - I2C_MODULE_INITIAL_ADDRESS + 1][0] = i;
      do {
        BUS_I2C.beginTransmission(I2C_MODULE_SETUP_ADDRESS);
        BUS_I2C.write(i);
      } while (BUS_I2C.endTransmission() != 0);
    } else {
      break;
    }
  }
  module_qty = i - I2C_MODULE_INITIAL_ADDRESS;
}

void module_plugin_detection(void) {

  uint8_t i = 1;

  if (module_list[I2C_MODULE_INITIAL_ADDRESS][0]) {
    do {
      delay(3500);
      SERIAL_PC_PORT.print(MODULE_PLUGIN_REGISTERING);
      SERIAL_PC_PORT.print(" ");
      SERIAL_PC_PORT.println(i);
      get_power_plugin(i,1);
      get_com_plugin(i,1);
      get_func_plugin(i,1);
      SERIAL_PC_PORT.println(DONE);
      i++;
    } while (module_list[i][0]);
    SERIAL_PC_PORT.println(MODULE_PLUGIN_REGISTERED);
    SERIAL_PC_PORT.println(" ");
  }

}

void module_slave (void) {

	bool aux;

  digitalWrite(PIN_I2C_RES_DIS, 1);
  led_set(0xFF00FF);
  mux_out_select(MUX_PRE_MODULE);
  aux = 1;
  while (!digitalRead(PIN_MUX_OUT)) {
  	if (aux) {
    SERIAL_PC_PORT.println(WAITING_FOR_MASTER);
}
aux = 0;
  }
  BUS_I2C.begin(I2C_MODULE_SETUP_ADDRESS); // I2C slave mode in setup address
  aux = 1;
  while (!BUS_I2C.available()) {
  	if (aux) {
    SERIAL_PC_PORT.println(WAITING_FOR_ADDRESS_ASSIGN);
}
aux = 0;
  }
  module_list[0][0] = BUS_I2C.read();
  BUS_I2C.begin(module_list[0][0]); // I2C slave mode in final assigned address
  SERIAL_PC_PORT.print(ADDRESS_OBTAINED);
  SERIAL_PC_PORT.println(module_list[0][0]);
  digitalWrite(PIN_POST_MODULE, 1);

  BUS_I2C.onReceive(receiveEvent); // Register I2C event
  BUS_I2C.onRequest(requestEvent); // Register I2C event

  delay(1000);

  for (int i = 0; i < module_list[0][0]; i++) { // LED blink the I2C address
    led_set(0x000000);
    delay(1000);
    led_set(0xFF00FF);
    delay(1000);
  }

}

uint8_t get_module_qty (void) {

  return module_qty;

}

void setup_print (void) {

  uint8_t i = I2C_MODULE_INITIAL_ADDRESS;
  SERIAL_PC_PORT.println(" ");
  SERIAL_PC_PORT.print(PLUGINS_DETECTED);
  SERIAL_PC_PORT.println(":");
  SERIAL_PC_PORT.print(POWER_PLUGIN);
  SERIAL_PC_PORT.print(" -> ");
  if (!get_power_plugin()) {
    SERIAL_PC_PORT.println(PLUGIN_NOT_DETECTED);
  } else {
    SERIAL_PC_PORT.println(power_plugins_name[get_power_plugin()]);
  }
  SERIAL_PC_PORT.print(COM_PLUGIN);
  SERIAL_PC_PORT.print(" -> ");
  if (!get_com_plugin()) {
    SERIAL_PC_PORT.println(PLUGIN_NOT_DETECTED);
  } else {
    SERIAL_PC_PORT.println(com_plugins_name[get_com_plugin()]);
  }
  SERIAL_PC_PORT.print(FUNC_PLUGIN);
  SERIAL_PC_PORT.print(" -> ");
  if (!get_func_plugin()) {
    SERIAL_PC_PORT.println(PLUGIN_NOT_DETECTED);
  } else {
    SERIAL_PC_PORT.println(func_plugins_name[get_func_plugin()]);
  }
  mux_out_select(MUX_BAT);
  SERIAL_PC_PORT.print(SYSTEM_VOLTAGE_LEVEL);
  SERIAL_PC_PORT.print(" -> ");
  SERIAL_PC_PORT.print(analogRead(PIN_MUX_OUT) / 29.7);
  SERIAL_PC_PORT.println("V");
  SERIAL_PC_PORT.print("USB -> ");
  if (digitalRead(PIN_USB_STAT)) {
    SERIAL_PC_PORT.println(USB_CONNECTED);
  } else {
    SERIAL_PC_PORT.println(USB_NOT_CONNECTED);
  }
  if (module_list[i][0]) {
    do {
      SERIAL_PC_PORT.println(" ");
      SERIAL_PC_PORT.print(MODULE_FOUND_IN_POSITION);
      SERIAL_PC_PORT.print(" ");
      SERIAL_PC_PORT.println(i);
      SERIAL_PC_PORT.print(POWER_PLUGIN);
      SERIAL_PC_PORT.print(" -> ");
      if (!module_list[i][1]) {
        SERIAL_PC_PORT.println(PLUGIN_NOT_DETECTED);
      } else {
        SERIAL_PC_PORT.println(power_plugins_name[module_list[i][1]]);
      }
      SERIAL_PC_PORT.print(COM_PLUGIN);
      SERIAL_PC_PORT.print(" -> ");
      if (!module_list[i][2]) {
        SERIAL_PC_PORT.println(PLUGIN_NOT_DETECTED);
      } else {
        SERIAL_PC_PORT.println(com_plugins_name[module_list[i][2]]);
      }
      SERIAL_PC_PORT.print(FUNC_PLUGIN);
      SERIAL_PC_PORT.print(" -> ");
      if (!module_list[i][3]) {
        SERIAL_PC_PORT.println(PLUGIN_NOT_DETECTED);
      } else {
        SERIAL_PC_PORT.println(func_plugins_name[module_list[i][3]]);
      }
      i++;
      delay(200);
    } while (module_list[i][0] != 0);
  } else if (!master0_or_slave1) {
    SERIAL_PC_PORT.println(" ");
    SERIAL_PC_PORT.println(NOT_ADDITIONAL_MODULES_DETECTED);
  }

}

// POWER PLUGINS CODE

void power_plugin_init (int power_plugin1) {

  switch (power_plugin1) {
    case 1:

      // No power plugin needs to be initialized

      break;
  }

}

// COM PLUGINS CODE

void com_plugin_init (int com_plugin1) {

	uint8_t count = 0;

  switch (com_plugin1) {

    // case 2: // KNX plugin

    //   pinMode(PIN_GPIO9, INPUT);
    //   pinMode(PIN_GPIO10, INPUT);
    //   if (Knx.begin(SERIAL_COM_PLUGIN_PORT, P_ADDR(knx_address[2], knx_address[1], knx_address[0])) != KNX_DEVICE_OK) {
    //     SERIAL_PC_PORT.println("Error conectando al plugin KNX");
    //     error_code = 1;
    //   } else {
    //     SERIAL_PC_PORT.println("Éxito conectando al plugin KNX");
    //   }

    //   break;

    case 2: // RS485 plugin

      pinMode(PIN_GPIO9, OUTPUT);
      pinMode(PIN_GPIO10, OUTPUT);
      #ifdef MODBUS_LAYER
      #endif
      #ifndef MODBUS_LAYER
      RS485.begin(9600);
      #endif

      break;

    case 4: // WIFI plugin

      pinMode(PIN_GPIO9, INPUT);
      pinMode(PIN_GPIO10, OUTPUT);

      //SERIAL_COM_PLUGIN_PORT.print("AT+RST\r\n");

      if (esp8266.begin() != true) {
        SERIAL_PC_PORT.println(WIFI_PLUGIN_COM_BAD);
        error_code = 1;
        return;
      } else {
        SERIAL_PC_PORT.println(WIFI_PLUGIN_COM_OK);
      }

      delay(50);

      if (esp8266.setMode(ESP8266_MODE_STAAP) < 0) {
        SERIAL_PC_PORT.println(WIFI_PLUGIN_CONF_BAD);
        error_code = 1;
        return;
      } else {
        SERIAL_PC_PORT.println(WIFI_PLUGIN_CONF_OK);
      }

      if (strlen(WiFi_Password) >= 8) {

      SERIAL_PC_PORT.print(CONNECTING_TO_WIFI_NETWORK);
      SERIAL_PC_PORT.print(" '");
      SERIAL_PC_PORT.print(WiFi_SSID);
      SERIAL_PC_PORT.print("' ");
      SERIAL_PC_PORT.print(WITH_PASSWORD);
      SERIAL_PC_PORT.print(" '");
      SERIAL_PC_PORT.print(WiFi_Password);
      SERIAL_PC_PORT.println("'");

        if (esp8266.status() <= 0) {

    while (esp8266.connect(WiFi_SSID, WiFi_Password) < 0 && count < 1)
      count++;
      if (count >= 1) {
        SERIAL_PC_PORT.println(WIFI_NETWORK_CON_BAD);
      	error_code = 1;
      	return;
      }

        SERIAL_PC_PORT.println(WIFI_NETWORK_CON_OK);
  }

} else {
SERIAL_PC_PORT.println(WIFI_CREDENTIALS_NOT_FOUND);
error_code = 1;
return;
}

      //SERIAL_COM_PLUGIN_PORT.print("AT+CWLAP\r\n");

      break;
  }

}

// FUNC PLUGINS CODE

void func_plugin_init (int func_plugin1) {

  switch (func_plugin1) {

    case 1: // Relay plugin

      pinMode(PIN_GPIO1, OUTPUT);
      pinMode(PIN_GPIO2, OUTPUT);
      pinMode(PIN_GPIO5, INPUT_PULLDOWN);
      pinMode(PIN_GPIO6, INPUT_PULLDOWN);
      pinMode(PIN_GPIO7, INPUT_PULLDOWN);
      pinMode(PIN_GPIO8, INPUT_PULLDOWN);

      break;

    case 2: // DC Motor plugin

      pinMode(PIN_GPIO1, OUTPUT);
      pinMode(PIN_GPIO2, INPUT_PULLDOWN);
      pinMode(PIN_GPIO3, OUTPUT);
      pinMode(PIN_GPIO4, INPUT_PULLDOWN);
      pinMode(PIN_GPIO5, OUTPUT);
      pinMode(PIN_GPIO6, OUTPUT);
      pinMode(PIN_GPIO7, OUTPUT);
      pinMode(PIN_GPIO8, OUTPUT);
      pinMode(PIN_SERIAL1_TX, INPUT_PULLDOWN);
      pinMode(PIN_SERIAL1_RX, INPUT_PULLDOWN);

      break;

    case 3: // Stepper Motor plugin

      pinMode(PIN_GPIO1, OUTPUT);
      pinMode(PIN_GPIO2, OUTPUT);
      pinMode(PIN_GPIO3, INPUT);
      pinMode(PIN_GPIO4, OUTPUT);
      pinMode(PIN_GPIO5, INPUT_PULLDOWN);
      pinMode(PIN_GPIO6, INPUT_PULLDOWN);
      pinMode(PIN_GPIO7, INPUT_PULLDOWN);
      pinMode(PIN_GPIO8, INPUT_PULLDOWN);

      digitalWrite(PIN_GPIO4, 0);
      stepper.begin(RPM);
      stepper.setSpeedProfile(stepper.LINEAR_SPEED, MOTOR_ACCEL, MOTOR_DECEL);

      break;

    case 4: // Servo control plugin

      S1.attach(PIN_GPIO1);
      S2.attach(PIN_GPIO2);
      S3.attach(PIN_GPIO3);
      S4.attach(PIN_GPIO4);
      S5.attach(PIN_GPIO5);
      S6.attach(PIN_GPIO6);
      S7.attach(PIN_GPIO7);
      S8.attach(PIN_GPIO8);

      break;

    case 5: // Digital IO plugin

      pinMode(PIN_GPIO1, OUTPUT);
      pinMode(PIN_GPIO2, OUTPUT);
      pinMode(PIN_GPIO3, OUTPUT);
      pinMode(PIN_GPIO4, OUTPUT);
      pinMode(PIN_GPIO5, OUTPUT);
      pinMode(PIN_GPIO6, OUTPUT);
      pinMode(PIN_GPIO7, OUTPUT);
      pinMode(PIN_GPIO8, OUTPUT);
      pinMode(PIN_SPI_PLUGIN_SS, OUTPUT);
      pinMode(PIN_SERIAL1_RX, OUTPUT);
      pinMode(PIN_SPI_MOSI, OUTPUT);
      pinMode(PIN_SERIAL1_TX, INPUT);

      break;

    case 6: // Analog IO plugin

      pinMode(PIN_GPIO1, OUTPUT);
      pinMode(PIN_GPIO2, OUTPUT);
      pinMode(PIN_GPIO3, OUTPUT);
      pinMode(PIN_GPIO4, OUTPUT);
      pinMode(PIN_GPIO5, OUTPUT);
      pinMode(PIN_GPIO6, OUTPUT);
      pinMode(PIN_GPIO7, OUTPUT);
      pinMode(PIN_GPIO8, OUTPUT);
      pinMode(PIN_SPI_PLUGIN_SS, OUTPUT);
      pinMode(PIN_SERIAL1_RX, OUTPUT);
      pinMode(PIN_SPI_MOSI, OUTPUT);
      pinMode(PIN_SERIAL1_TX, INPUT);

      break;

    case 7: // 0-20mA IO plugin

      break;

    case 8: // Power measure plugin

      pinMode(PIN_GPIO1, OUTPUT);
      pinMode(PIN_GPIO2, OUTPUT);
      pinMode(PIN_GPIO3, OUTPUT);
      pinMode(PIN_GPIO4, OUTPUT);
      pinMode(PIN_GPIO5, INPUT);
      pinMode(PIN_GPIO8, INPUT);

      break;

    case 9: // Audio Player plugin

      pinMode(PIN_GPIO1, INPUT);
      pinMode(PIN_GPIO3, INPUT_PULLDOWN);
      pinMode(PIN_GPIO4, INPUT_PULLDOWN);
      pinMode(PIN_GPIO5, INPUT_PULLDOWN);
      pinMode(PIN_GPIO6, INPUT_PULLDOWN);
      pinMode(PIN_GPIO7, INPUT_PULLDOWN);
      pinMode(PIN_GPIO8, INPUT_PULLDOWN);

      //SERIAL_FUNC_PLUGIN_PORT.begin(9600);
      az_audio_player_plugin.begin(SERIAL_FUNC_PLUGIN_PORT);
      az_audio_player_plugin.volume(30);

      break;

    case 10: // Direct GPIO plugin


      break;

    case 11: // Load Cell plugin

      pinMode(PIN_GPIO1, INPUT);
      pinMode(PIN_GPIO2, OUTPUT);
      pinMode(PIN_GPIO3, OUTPUT);
      pinMode(PIN_GPIO4, OUTPUT);
      pinMode(PIN_GPIO5, INPUT);
      pinMode(PIN_GPIO7, INPUT_PULLDOWN);
      pinMode(PIN_GPIO8, INPUT_PULLDOWN);

      az_load_cell_plugin.begin(PIN_GPIO1, PIN_GPIO2);
      //az_load_cell_plugin.set_gain(64);
      az_load_cell_plugin.set_scale();
      az_load_cell_plugin.tare(10);

      break;

  }

}

void plugin_init (void) {
  com_plugin_init(com_plugin);
  power_plugin_init(power_plugin);
  func_plugin_init(func_plugin);
      for (int count = 1; count <= 16; count++) {
        az_digital_write(0, count, 0);
        az_analog_write(0, count, 0);
    }
}

// FUNC FUNCTIONS ///

int8_t az_digital_write (uint8_t module, uint8_t pin, bool command) { // 1

  if (module > 0) {

    BUS_I2C.beginTransmission(module);

    BUS_I2C.write(1);
    BUS_I2C.write(pin);
    BUS_I2C.write(command);
    BUS_I2C.write(0);

    BUS_I2C.endTransmission();

    BUS_I2C.requestFrom(module, 1);
    return BUS_I2C.read();

  }

  if (pin == COM1 || pin == COM2) {

    switch (com_plugin) {

      case 1: // RS485 plugin

        if (pin == COM1) {

          digitalWrite(PIN_GPIO9, command);
          return 1;

        } else if (pin == COM2) {

          digitalWrite(PIN_GPIO10, command);
          return 1;
        } else {
          return -1;
        }

        break;

      case 2: // KNX plugin

        if (pin == COM2) {

          digitalWrite(PIN_GPIO10, command);
          return 1;

        } else {
          return -1;
        }

        break;

      case 4: // WIFI plugin

        if (pin == COM2) {

          digitalWrite(PIN_GPIO10, command);
          return 1;

        } else {
          return -1;
        }

        break;

    }

    return 1;

  }

  switch (func_plugin) {

    case 1: // Relay plugin

      if (pin == T1) {
        if (command) {
          digitalWrite(PIN_GPIO1, 1);
        } else if (!command) {
          digitalWrite(PIN_GPIO1, 0);
        }
        return 1;
      } else if (pin == T2) {
        if (command) {
          digitalWrite(PIN_GPIO2, 1);
        } else if (!command) {
          digitalWrite(PIN_GPIO2, 0);
        }
        return 1;
      } else {
        return -1;
      }

      break;

    case 2: // DC Motor plugin

      if (pin == T1) {
        digitalWrite(PIN_GPIO5, 1);
        digitalWrite(PIN_GPIO6, 0);
        if (command) {
          digitalWrite(PIN_GPIO1, 1);
        } else {
          digitalWrite(PIN_GPIO1, 0);
        }
      } else if (pin == T2) {
        digitalWrite(PIN_GPIO5, 0);
        digitalWrite(PIN_GPIO6, 1);
        if (command) {
          digitalWrite(PIN_GPIO1, 1);
        } else {
          digitalWrite(PIN_GPIO1, 0);
        }
      } else if (pin == T3) {
        digitalWrite(PIN_GPIO7, 1);
        digitalWrite(PIN_GPIO8, 0);
        if (command) {
          digitalWrite(PIN_GPIO3, 1);
        } else {
          digitalWrite(PIN_GPIO3, 0);
        }
      } else if (pin == T4) {
        digitalWrite(PIN_GPIO7, 0);
        digitalWrite(PIN_GPIO8, 1);
        if (command) {
          digitalWrite(PIN_GPIO3, 1);
        } else {
          digitalWrite(PIN_GPIO3, 0);
        }
      } else {
        return -1;
      }
        return 1;

      break;

    case 3: // Stepper motor plugin

      if (pin == T1) {
        if (command) {
          digitalWrite(PIN_GPIO1, 1);
        } else if (!command) {
          digitalWrite(PIN_GPIO1, 0);
        }
        return 1;
      } else if (pin == T2) {
        if (command) {
          digitalWrite(PIN_GPIO2, 1);
        } else if (!command) {
          digitalWrite(PIN_GPIO2, 0);
        }
        return 1;
      } else if (pin == T3) {
        if (command) {
          digitalWrite(PIN_GPIO4, 1);
        } else if (!command) {
          digitalWrite(PIN_GPIO4, 0);
        }
        return 1;
      } else {
        return -1;
      }

      break;

    case 4: // Servo control plugin

      if (pin == T1) {
        if (command) {
          S1.write(255);
        } else {
          S1.write(0);
        }
        return 1;
      } else if (pin == T2) {
        if (command) {
          S2.write(255);
        } else {
          S2.write(0);
        }
        return 1;
      } else if (pin == T3) {
        if (command) {
          S3.write(255);
        } else {
          S3.write(0);
        }
        return 1;
      } else if (pin == T4) {
        if (command) {
          S4.write(255);
        } else {
          S4.write(0);
        }
        return 1;
      } else if (pin == T5) {
        if (command) {
          S5.write(255);
        } else {
          S5.write(0);
        }
        return 1;
      } else if (pin == T6) {
        if (command) {
          S6.write(255);
        } else {
          S6.write(0);
        }
        return 1;
      } else if (pin == T7) {
        if (command) {
          S7.write(255);
        } else {
          S7.write(0);
        }
        return 1;
      } else if (pin == T8) {
        if (command) {
          S8.write(255);
        } else {
          S8.write(0);
        }
        return 1;
      } else {
        return -1;
      }

      break;

    case 5: // Digital IO plugin

      if (pin == T9) {
        digitalWrite(PIN_GPIO1, command);
        return 1;
      } else if (pin == T10) {
        digitalWrite(PIN_GPIO2, command);
        return 1;
      } else if (pin == T11) {
        digitalWrite(PIN_GPIO3, command);
        return 1;
      } else if (pin == T12) {
        digitalWrite(PIN_GPIO4, command);
        return 1;
      } else if (pin == T13) {
        digitalWrite(PIN_GPIO5, command);
        return 1;
      } else if (pin == T14) {
        digitalWrite(PIN_GPIO6, command);
        return 1;
      } else if (pin == T15) {
        digitalWrite(PIN_GPIO7, command);
        return 1;
      } else if (pin == T16) {
        digitalWrite(PIN_GPIO8, command);
        return 1;
      }
      return -1;

      break;

    case 6: // Analog IO plugin

      if (pin == T9) {
        digitalWrite(PIN_GPIO1, command);
        return 1;
      } else if (pin == T10) {
        digitalWrite(PIN_GPIO2, command);
        return 1;
      } else if (pin == T11) {
        digitalWrite(PIN_GPIO3, command);
        return 1;
      } else if (pin == T12) {
        digitalWrite(PIN_GPIO4, command);
        return 1;
      } else if (pin == T13) {
        digitalWrite(PIN_GPIO5, command);
        return 1;
      } else if (pin == T14) {
        digitalWrite(PIN_GPIO6, command);
        return 1;
      } else if (pin == T15) {
        digitalWrite(PIN_GPIO7, command);
        return 1;
      } else if (pin == T16) {
        digitalWrite(PIN_GPIO8, command);
        return 1;
      }
      return -1;

      break;

    case 7: // 0-20mA IO plugin

	return -1;
      break;

    case 8: //Power measure plugin

	return -1;
      break;

    case 9: // Audio Player plugin
    if (!command) {
        az_audio_player_plugin.reset();
    }
  return -1;
      break;

    case 10: // Direct GPIO plugin

      if (pin == T1) {
        pinMode(PIN_GPIO1, OUTPUT);
        digitalWrite(PIN_GPIO1, command);
        return 1;
      } else if (pin == T2) {
        pinMode(PIN_GPIO2, OUTPUT);
        digitalWrite(PIN_GPIO2, command);
        return 1;
      } else if (pin == T3) {
        pinMode(PIN_GPIO3, OUTPUT);
        digitalWrite(PIN_GPIO3, command);
        return 1;
      } else if (pin == T4) {
        pinMode(PIN_GPIO4, OUTPUT);
        digitalWrite(PIN_GPIO4, command);
        return 1;
      } else if (pin == T5) {
        pinMode(PIN_GPIO5, OUTPUT);
        digitalWrite(PIN_GPIO5, command);
        return 1;
      } else if (pin == T6) {
        pinMode(PIN_GPIO6, OUTPUT);
        digitalWrite(PIN_GPIO6, command);
        return 1;
      } else if (pin == T7) {
        pinMode(PIN_GPIO7, OUTPUT);
        digitalWrite(PIN_GPIO7, command);
        return 1;
      } else if (pin == T8) {
        pinMode(PIN_GPIO8, OUTPUT);
        digitalWrite(PIN_GPIO8, command);
        return 1;
      } else if (pin == T9) {
        pinMode(PIN_SPI_PLUGIN_SS, OUTPUT);
        digitalWrite(PIN_SPI_PLUGIN_SS, command);
        return 1;
      } else if (pin == T10) {
        pinMode(PIN_SPI_SCK, OUTPUT);
        digitalWrite(PIN_SPI_SCK, command);
        return 1;
      } else if (pin == T11) {
        pinMode(PIN_SPI_MOSI, OUTPUT);
        digitalWrite(PIN_SPI_MOSI, command);
        return 1;
      } else if (pin == T12) {
        pinMode(PIN_SPI_MISO, OUTPUT);
        digitalWrite(PIN_SPI_MISO, command);
        return 1;
      } else if (pin == T13) {
        pinMode(PIN_PLUGIN_I2C_SDA, OUTPUT);
        digitalWrite(PIN_PLUGIN_I2C_SDA, command);
        return 1;
      } else if (pin == T14) {
        pinMode(PIN_PLUGIN_I2C_SCL, OUTPUT);
        digitalWrite(PIN_PLUGIN_I2C_SCL, command);
        return 1;
      } else if (pin == T15) {
        pinMode(PIN_SERIAL1_RX, OUTPUT);
        digitalWrite(PIN_SERIAL1_TX, command);
        return 1;
      } else if (pin == T16) {
        pinMode(PIN_SERIAL1_TX, OUTPUT);
        digitalWrite(PIN_SERIAL1_RX, command);
        return 1;
      } else {
        return -1;
      }

      break;

    case 11: // Load Cell plugin

	return -1;
      break;

    default:
      return -1;
      break;

  }
}

int8_t az_digital_read (uint8_t module, uint8_t pin) { // 2

  int8_t i = 0;

  if (module > 0) {

    SERIAL_PC_PORT.print("Inicio transmisión a esclavo ");
    SERIAL_PC_PORT.println(module);
    BUS_I2C.beginTransmission(module);

    BUS_I2C.write(2);
    BUS_I2C.write(pin);
    BUS_I2C.write(0);
    BUS_I2C.write(0);

    BUS_I2C.endTransmission();

    BUS_I2C.requestFrom(module, 1);
    return BUS_I2C.read();

  }

  if (pin == COM1 || pin == COM2) {

    switch (com_plugin) {

      case 1: // RS485 plugin

        if (pin == COM1) {

          return digitalRead(PIN_GPIO9);

        } else if (pin == COM2) {

          return digitalRead(PIN_GPIO10);

        } else {
          return -1;
        }

        break;

      case 2: // KNX plugin

        if (pin == COM1) {

          return digitalRead(PIN_GPIO9);

        } else {
          return -1;
        }

        break;

      case 4: // WIFI plugin

        if (pin == COM1) {

          return digitalRead(PIN_GPIO9);

        } else {
          return -1;
        }

        break;

    }

    return 1;

  }

  switch (func_plugin) {
    
    case 1: // Relay plugin

      if (pin == T1) {
        return digitalRead(PIN_GPIO1);
      } else if (pin == T2) {
        return digitalRead(PIN_GPIO1);
      } else if (pin == T3) {
        return digitalRead(PIN_GPIO2);
      } else if (pin == T4) {
        return digitalRead(PIN_GPIO2);
      } else if (pin == T5) {
        return digitalRead(PIN_GPIO5);
      } else if (pin == T6) {
        return digitalRead(PIN_GPIO6);
      } else if (pin == T7) {
        return digitalRead(PIN_GPIO7);
      } else if (pin == T8) {
        return digitalRead(PIN_GPIO8);
      } else {
        return -1;
      }

      break;

    case 2: // DC Motor plugin

      if (pin == T1) {
        return digitalRead(PIN_GPIO5);
      } else if (pin == T2) {
        return digitalRead(PIN_GPIO6);
      } else if (pin == T3) {
        return digitalRead(PIN_GPIO7);
      } else if (pin == T4) {
        return digitalRead(PIN_GPIO8);
      } else if (pin == T5) {
        return digitalRead(PIN_GPIO2);
      } else if (pin == T6) {
        return digitalRead(PIN_GPIO4);
      } else if (pin == T7) {
        return digitalRead(PIN_SERIAL1_RX);
      } else if (pin == T8) {
        return digitalRead(PIN_SERIAL1_TX);
      } else {
        return -1;
      }

      break;

    case 3: // Stepper plugin

      if (pin >= T1 && pin <= T8) {
        return digitalRead(PIN_GPIO3);
      } else if (pin == T5) {
        return digitalRead(PIN_GPIO5);
      } else if (pin == T6) {
        return digitalRead(PIN_GPIO6);
      } else if (pin == T7) {
        return digitalRead(PIN_GPIO7);
      } else if (pin == T8) {
        return digitalRead(PIN_GPIO8);
      } else {
        return -1;
      }

      return 1;

      break;

    case 4: // Servo control plugin

  return -1;
    break;

    case 5: // Digital IO plugin

      if (pin >= T1 && pin <= T8) {
              pin = pin-1;
              digitalWrite(PIN_SPI_PLUGIN_SS, bitRead(pin, 0));
              digitalWrite(PIN_SERIAL1_RX, bitRead(pin, 1));
              digitalWrite(PIN_SPI_MOSI, bitRead(pin, 2));

              delayMicroseconds(1);
              return digitalRead(PIN_SERIAL1_TX);
          } else if (pin >= T9 && pin <= T16) {

        switch(pin) {
        case T9:
        return digitalRead(PIN_GPIO1);
        break;
        case T10:
        return digitalRead(PIN_GPIO2);
        break;
        case T11:
        return digitalRead(PIN_GPIO3);
        break;
        case T12:
        return digitalRead(PIN_GPIO4);
        break;
        case T13:
        return digitalRead(PIN_GPIO5);
        break;
        case T14:
        return digitalRead(PIN_GPIO6);
        break;
        case T15:
        return digitalRead(PIN_GPIO7);
        break;
        case T16:
        return digitalRead(PIN_GPIO8);
        break;

    }

          }
          return -1;

      break;

    case 6: // Analog IO plugin

      if (pin >= T1 && pin <= T8) {
              pin = pin-1;
              digitalWrite(PIN_SPI_PLUGIN_SS, bitRead(pin, 0));
              digitalWrite(PIN_SERIAL1_RX, bitRead(pin, 1));
              digitalWrite(PIN_SPI_MOSI, bitRead(pin, 2));

              delayMicroseconds(1);
              return digitalRead(PIN_SERIAL1_TX);
          }
          return -1;

    break;

    case 7: // 0-20mA IO plugin

	return -1;
    break;

    case 8: // Power measure plugin

	return -1;
    break;

    case 9: // Audio player plugin

      if (pin == T1) {
        return digitalRead(PIN_GPIO1);
      } else if (pin == T2) {
        return digitalRead(PIN_GPIO1);
      } else if (pin == T3) {
        return digitalRead(PIN_GPIO3);
      } else if (pin == T4) {
        return digitalRead(PIN_GPIO4);
      } else if (pin == T5) {
        return digitalRead(PIN_GPIO5);
      } else if (pin == T6) {
        return digitalRead(PIN_GPIO6);
      } else if (pin == T7) {
        return digitalRead(PIN_GPIO7);
      } else if (pin == T8) {
        return digitalRead(PIN_GPIO8);
      } else {
        return -1;
      }

      break;

    case 10: // Direct GPIO plugin

      if (pin == T1) {
        pinMode(PIN_GPIO1, INPUT);
        return digitalRead(PIN_GPIO1);
      } else if (pin == T2) {
        pinMode(PIN_GPIO2, INPUT);
        return digitalRead(PIN_GPIO2);
      } else if (pin == T3) {
        pinMode(PIN_GPIO3, INPUT);
        return digitalRead(PIN_GPIO3);
      } else if (pin == T4) {
        pinMode(PIN_GPIO4, INPUT);
        return digitalRead(PIN_GPIO4);
      } else if (pin == T5) {
        pinMode(PIN_GPIO5, INPUT);
        return digitalRead(PIN_GPIO5);
      } else if (pin == T6) {
        pinMode(PIN_GPIO6, INPUT);
        return digitalRead(PIN_GPIO6);
      } else if (pin == T7) {
        pinMode(PIN_GPIO7, INPUT);
        return digitalRead(PIN_GPIO7);
      } else if (pin == T8) {
        pinMode(PIN_GPIO8, INPUT);
        return digitalRead(PIN_GPIO8);
      } else if (pin == T9) {
        pinMode(PIN_SPI_PLUGIN_SS, INPUT);
        return digitalRead(PIN_SPI_PLUGIN_SS);
      } else if (pin == T10) {
        pinMode(PIN_SPI_SCK, INPUT);
        return digitalRead(PIN_SPI_SCK);
      } else if (pin == T11) {
        pinMode(PIN_SPI_MOSI, INPUT);
        return digitalRead(PIN_SPI_MOSI);
      } else if (pin == T12) {
        pinMode(PIN_SPI_MISO, INPUT);
        return digitalRead(PIN_SPI_MISO);
      } else if (pin == T13) {
        pinMode(PIN_PLUGIN_I2C_SDA, INPUT);
        return digitalRead(PIN_PLUGIN_I2C_SDA);
      } else if (pin == T14) {
        pinMode(PIN_PLUGIN_I2C_SCL, INPUT);
        return digitalRead(PIN_PLUGIN_I2C_SCL);
      } else if (pin == T15) {
        pinMode(PIN_SERIAL1_RX, INPUT);
        return digitalRead(PIN_SERIAL1_RX);
      } else if (pin == T16) {
        pinMode(PIN_SERIAL1_TX, INPUT);
        return digitalRead(PIN_SERIAL1_TX);
      } else {
        return -1;
      }

      return 1;

      break;

    case 11: // Load Cell plugin

      if (pin >= T7 && pin <= T8) {

        return digitalRead(pin);

      } else {
        return -1;
      }

      break;

    default:
      return -1;
      break;

  }
}

int8_t az_analog_write ( uint8_t module, uint8_t pin, int32_t command,bool percentage1_or_value0) { // 3

  int8_t i = 0;

  if (module > 0) {

    BUS_I2C.beginTransmission(module);

    BUS_I2C.write(3);
    BUS_I2C.write(pin);
    BUS_I2C.write(command);
    BUS_I2C.write(percentage1_or_value0);

    BUS_I2C.endTransmission();

    BUS_I2C.requestFrom(module, 1);
    return BUS_I2C.read();

  }

  int8_t temp = 0;

  if (percentage1_or_value0) {
    command = map(command, 0, 100, 0, 255);
  }

  switch (func_plugin) {

    case 1: // // Relay Plugin

    return -1;
    break;

    case 2: // DC Motor plugin

      if (pin == T1) {
        digitalWrite(PIN_GPIO5, 1);
        digitalWrite(PIN_GPIO6, 0);
          analogWrite(PIN_GPIO1, command);
      } else if (pin == T2) {
        digitalWrite(PIN_GPIO5, 0);
        digitalWrite(PIN_GPIO6, 1);
          analogWrite(PIN_GPIO1, command);
      } else if (pin == T3) {
        digitalWrite(PIN_GPIO7, 1);
        digitalWrite(PIN_GPIO8, 0);
          analogWrite(PIN_GPIO3, command);
      } else if (pin == T4) {
        digitalWrite(PIN_GPIO7, 0);
        digitalWrite(PIN_GPIO8, 1);
          analogWrite(PIN_GPIO3, command);
      } else {
        return -1;
      }
        return 1;

      break;

    case 3: // Stepper plugin

      if (pin == T1) {

        if (command) {
          stepper.startMove(command, stepper_working_time * 1000);
          stepper_working_time = 0;
        } else {
          stepper.startBrake();
        }

      } else if (pin == T2) {
        stepper.setRPM(command);
      } else if (pin == T3) {
        stepper_working_time = command;
      } else {
        return -1;
      }
      return 1;

      break;

    case 4: // Servo control plugin

      if (pin == T1) {
        S1.write(command);
      } else if (pin == T2) {
        S2.write(command);
      } else if (pin == T3) {
        S3.write(command);
      } else if (pin == T4) {
        S4.write(command);
      } else if (pin == T5) {
        S5.write(command);
      } else if (pin == T6) {
        S6.write(command);
      } else if (pin == T7) {
        S7.write(command);
      } else if (pin == T8) {
        S8.write(command);
      } else {
        return -1;
      }

      return 1;

      break;

    case 5: // Digital IO plugin

          return -1;

      break;

    case 6: // Analog IO plugin

      if (pin == T9) {
        analogWrite(PIN_GPIO1, command);
        return 1;
      } else if (pin == T10) {
        analogWrite(PIN_GPIO2, command);
        return 1;
      } else if (pin == T11) {
        analogWrite(PIN_GPIO3, command);
        return 1;
      } else if (pin == T12) {
        analogWrite(PIN_GPIO4, command);
        return 1;
      } else if (pin == T13) {
        analogWrite(PIN_GPIO5, command);
        return 1;
      } else if (pin == T14) {
        analogWrite(PIN_GPIO6, command);
        return 1;
      } else if (pin == T15) {
        analogWrite(PIN_GPIO7, command);
        return 1;
      } else if (pin == T16) {
        analogWrite(PIN_GPIO8, command);
        return 1;
      }
          return -1;

      break;

    case 7: // 0-20mA IO plugin

	return -1;
    break;

    case 8: // Power measure plugin

	return -1;
    break;

    case 12: // Audio Player plugin

      if (pin >= T1 && pin <= T2) {
        az_audio_player_plugin.play(command);
        return 1;

      } else {
        return -1;
      }

      break;

    case 10: // Direct GPIO plugin

      if (pin == T1) {
        pinMode(PIN_GPIO1, OUTPUT);
        analogWrite(PIN_GPIO1, command);
      } else if (pin == T2) {
        pinMode(PIN_GPIO2, OUTPUT);
        analogWrite(PIN_GPIO2, command);
      } else if (pin == T3) {
        pinMode(PIN_GPIO3, OUTPUT);
        analogWrite(PIN_GPIO3, command);
      } else if (pin == T4) {
        pinMode(PIN_GPIO4, OUTPUT);
        analogWrite(PIN_GPIO4, command);
      } else if (pin == T5) {
        pinMode(PIN_GPIO5, OUTPUT);
        analogWrite(PIN_GPIO5, command);
      } else if (pin == T6) {
        pinMode(PIN_GPIO6, OUTPUT);
        analogWrite(PIN_GPIO6, command);
      } else if (pin == T7) {
        pinMode(PIN_GPIO7, OUTPUT);
        analogWrite(PIN_GPIO7, command);
      } else if (pin == T8) {
        pinMode(PIN_GPIO8, OUTPUT);
        analogWrite(PIN_GPIO8, command);
      } else {
        return -1;
      }

      return 1;

      break;

    case 11: // Load Cell plugin

	return -1;
    break;

    default:
      return -1;
      break;

  }

}

int32_t az_analog_read (uint8_t module, uint8_t pin, bool percentage1_or_value0) {// 4

  int8_t i = 0;

  if (module > 0) {

    BUS_I2C.beginTransmission(module);

    BUS_I2C.write(3);
    BUS_I2C.write(pin);
    BUS_I2C.write(0);
    BUS_I2C.write(percentage1_or_value0);

    BUS_I2C.endTransmission();

    BUS_I2C.requestFrom(module, 1);
    return BUS_I2C.read();

  }

  int32_t temp = 0;

  switch (func_plugin) {

    case 1: // // Relay Plugin

    return -1;
    break;

    case 2: // DC Motor plugin

      if (pin == T1 || pin == T2) {
        analogRead(PIN_GPIO2);
        return 1;
      } else if (pin == T3 || pin == T4) {
        analogRead(PIN_GPIO4);
        return 1;
      } else {
        return -1;
      }

      break;

    case 3: // Stepper plugin

      if (pin >= T1 && pin <= T4) {
        temp = stepper.getCurrentState();
      } else {
        return -1;
      }

      break;

    case 4: // Servo control plugin

  return -1;
    break;

    case 5: // Digital IOplugin

    return -1;
      break;

    case 6: // Analog IO plugin

      if (pin >= T1 && pin <= T8) {
              digitalWrite(PIN_SPI_PLUGIN_SS, bitRead(pin, 0));
              digitalWrite(PIN_SERIAL1_TX, bitRead(pin, 1));
              digitalWrite(PIN_SPI_MOSI, bitRead(pin, 2));

              delayMicroseconds(1);
              temp = analogRead(PIN_SERIAL1_RX);
          }

      //temp = map(temp, 0, 1023, 0, 20000);

      break;

    case 7: // 0-20mA IO plugin

	return -1;
    break;

    case 8: // Power measure plugin

      if (pin >= T1 && pin <= T16) {
      	pin = pin-1;

              digitalWrite(PIN_GPIO1, bitRead(pin, 0));
              digitalWrite(PIN_GPIO2, bitRead(pin, 1));
              digitalWrite(PIN_GPIO3, bitRead(pin, 2));
              digitalWrite(PIN_GPIO4, bitRead(pin, 3));

              delayMicroseconds(1);
              temp = analogRead(PIN_GPIO8);

      } else if (pin == 17) {
        temp = analogRead(PIN_GPIO5);
      } else {
        return -1;
      }

      break;

    case 9: // Audio Player plugin

      if (pin >= T1 && pin <= T2) {

        temp = az_audio_player_plugin.currentTrack();

      } else {
        return -1;
      }

      break;

    case 10: // Direct output plugin

      if (pin == T1) {
        pinMode(PIN_GPIO1, INPUT);
        temp = analogRead(PIN_GPIO1);
      } else if (pin == T2) {
        pinMode(PIN_GPIO2, INPUT);
        temp = analogRead(PIN_GPIO2);
      } else if (pin == T3) {
        pinMode(PIN_GPIO3, INPUT);
        temp = analogRead(PIN_GPIO3);
      } else if (pin == T4) {
        pinMode(PIN_GPIO4, INPUT);
        temp = analogRead(PIN_GPIO4);
      } else if (pin == T5) {
        pinMode(PIN_GPIO5, INPUT);
        temp = analogRead(PIN_GPIO5);
      } else if (pin == T6) {
        pinMode(PIN_GPIO6, INPUT);
        temp = analogRead(PIN_GPIO6);
      } else if (pin == T7) {
        pinMode(PIN_GPIO7, INPUT);
        temp = analogRead(PIN_GPIO7);
      } else if (pin == T8) {
        pinMode(PIN_GPIO8, INPUT);
        temp = analogRead(PIN_GPIO8);
      } else {
        return -1;
      }

      break;

    case 11: // Load Cell plugin

      if (pin == T1 || pin == T2) {
      digitalWrite(PIN_GPIO4, 0);
      digitalWrite(PIN_GPIO3, 0);
        if (az_load_cell_plugin.is_ready()) {

    return az_load_cell_plugin.get_value();

  } else {
    return -1;
  }
      } else if (pin == T3 || pin == T4) {
      digitalWrite(PIN_GPIO4, 0);
      digitalWrite(PIN_GPIO3, 1);
        if (az_load_cell_plugin.is_ready()) {

    return az_load_cell_plugin.get_value();

  } else {
    return -1;
  }
      } else if (pin == 17) {
        temp = analogRead(PIN_GPIO5);
      } else {
        return -1;
      }

      break;

    default:
      return -1;
      break;

  }

  if (percentage1_or_value0) {
    temp = map(temp, 0, 1023, 0, 100);
  }

  return temp;

}

int8_t az_read_temperature (uint8_t module) {

	if (get_func_plugin() != 8 && get_func_plugin() != 11) {
		return -1;
	}

	return az_analog_read(module, 17);

}

int8_t az_relay_switch (uint8_t module, uint8_t relay, bool command) {

	if (get_func_plugin() != 1) {
		return -1;
	}

	switch (relay) {
		case 1:
	relay = T1;
		break;
		case 2:
	relay = T3;
		break;
    case 3:
    break;
		default:
	relay = 0;
		break;
	}
	return az_digital_write(module, relay, command);

}

int8_t az_relay_state (uint8_t module, uint8_t relay) {

	if (get_func_plugin() != 1) {
		return -1;
	}

	switch (relay) {
		case 1:
	relay = T1;
		break;
		case 2:
	relay = T3;
		break;
    case 3:
    break;
		default:
	relay = 0;
		break;
	}
	return az_digital_read(module, relay);

}

int8_t az_dcmotor_max_move (uint8_t module, uint8_t motor, bool command, bool direction) {

	if (get_func_plugin() != 2) {
		return -1;
	}

	switch (motor) {
		case 1:
	motor = T1;
		break;
		case 2:
	motor = T3;
		break;
    case 3:
    break;
		default:
	motor = 0;
		break;
	}
if (direction) {
  motor++;
}

	return az_digital_write(module, motor, command);
}

int8_t az_dcmotor_half_bridge_state (uint8_t module, uint8_t motor, bool direction) {

	if (get_func_plugin() != 2) {
		return -1;
	}


	switch (motor) {
		case 1:
	motor = T1;
		break;
		case 2:
	motor = T3;
		break;
    case 3:
    break;
		default:
	motor = 0;
		break;
	}
if (direction) {
  motor++;
}

	return az_digital_read(module, motor);
}

int8_t az_dcmotor_set_speed (uint8_t module, uint8_t motor, uint8_t speed, bool direction) {

	if (get_func_plugin() != 2) {
		return -1;
	}

	switch (motor) {
		case 1:
	motor = T1;
		break;
		case 2:
	motor = T3;
		break;
    case 3:
    break;
		default:
	motor = 0;
		break;
	}
if (direction) {
  motor++;
}
	return az_analog_write(module, motor, speed);
}

int8_t az_dcmotor_power_read (uint8_t module, uint8_t motor) {

	if (get_func_plugin() != 2) {
		return -1;
	}

	switch (motor) {
		case 1:
	motor = T1;
		break;
		case 2:
	motor = T3;
		break;
    case 3:
    break;
		default:
	motor = 0;
		break;
	}
	return az_analog_read(module, motor);
}

int8_t az_stmotor_step_control (uint8_t module, uint8_t motor, bool command, bool direction) {

	if (get_func_plugin() != 3) {
		return -1;
	}

	return az_digital_write(module, T1, command);
}

int8_t az_stmotor_dir_control (uint8_t module, uint8_t motor, bool command, bool direction) {

	if (get_func_plugin() != 3) {
		return -1;
	}

	return az_digital_write(module, T2, command);
}

int8_t az_stmotor_enable (uint8_t module, uint8_t motor, bool command) {

	if (get_func_plugin() != 3) {
		return -1;
	}

	return az_digital_write(module, T3, command);
}

int8_t az_stmotor_fault_state (uint8_t module, uint8_t motor) {

	if (get_func_plugin() != 3) {
		return -1;
	}

	return az_digital_read(module, T1);
}

int32_t az_stmotor_move_state (uint8_t module, uint8_t motor) {

	if (get_func_plugin() != 3) {
		return -1;
	}

	return az_analog_read(module, T1);
}

int8_t az_stmotor_set_rpm_speed (uint8_t module, uint8_t motor, uint32_t rpm_speed, bool direction) {

	if (get_func_plugin() != 3) {
		return -1;
	}

	return az_analog_write(module, T2, rpm_speed);
}

int8_t az_stmotor_move_degrees (uint8_t module, uint8_t motor, uint32_t degrees, bool direction, uint32_t time_to_accomplish_ms) {

	if (get_func_plugin() != 3) {
		return -1;
	}

	int32_t steps;

	steps = degrees*MOTOR_STEPS;
	if (direction) {
		steps = steps-2*steps;
	}
	az_analog_write(module, T3, time_to_accomplish_ms);
	return az_analog_write(module, T1, steps);

}

int32_t az_power_measure_read (uint8_t module, uint8_t coil) {

	if (get_func_plugin() != 8) {
		return -1;
	}

	return az_analog_read(module, coil);

}

int8_t az_servo_set_degrees (uint8_t module, uint8_t servo, int32_t degrees) {

	if (get_func_plugin() != 9) {
		return -1;
	}

	degrees = map(degrees,0,120,0,256);
	return az_analog_write(module, servo, degrees);

}

int32_t az_load_cell_read (uint8_t module, uint8_t cell) {

	if (get_func_plugin() != 11) {
		return -1;
	}

  switch (cell) {
    case 1:
    cell = T1;
      break;
    case 2:
    cell = T3;
      break;
    default:
    cell = 0;
  }

return az_analog_read(module, cell);

}

int8_t az_audio_stop (uint8_t module) {

	if (get_func_plugin() != 12) {
		return -1;
	}

	return az_digital_write(module,T1,0);
}
int8_t az_audio_play_track (uint8_t module, uint16_t track) {

	if (get_func_plugin() != 12) {
		return -1;
	}

	return az_analog_write(module, T1, track);

}
int8_t az_audio_get_current_track (uint8_t module) {

	if (get_func_plugin() != 12) {
		return -1;
	}

	return az_analog_read(module, T1);

}

int8_t indexed_functions (uint8_t function_index, uint8_t pin, uint8_t command, uint8_t per1_val0) {

  switch (function_index) {
    case 1:
      return az_digital_write(0, pin, command);
      break;

    case 2:
      return az_digital_read(0, pin);
      break;

    case 3:
      return az_analog_write(0, pin, command, per1_val0);
      break;

    case 4:
      return az_analog_read(0, pin, per1_val0);
      break;

    case 5:
      return get_power_plugin();
      break;

    case 6:
      return get_com_plugin();
      break;

    case 7:
      return get_func_plugin();
      break;

  }
  
  return 0;

}

bool master0_or_slave1_detection (void) {

mux_out_select(MUX_PRE_MODULE);
return !unconnected_pin_detect(PIN_MUX_OUT);

}


// INIT SEQUENCE

void az_setup (void) {

  pinMode(PIN_MUX_OUT, INPUT);
  pinMode(PIN_CHARGING_STAT, INPUT);
  pinMode(PIN_USB_STAT, INPUT);
  pinMode(PIN_POST_MODULE, OUTPUT);
  pinMode(PIN_I2C_RES_DIS, OUTPUT);
  pinMode(PIN_LED_RGB, OUTPUT);
  pinMode(PIN_MUX_S0, OUTPUT);
  pinMode(PIN_MUX_S1, OUTPUT);
  pinMode(PIN_MUX_S2, OUTPUT);

  digitalWrite(PIN_POST_MODULE, 0);
  digitalWrite(PIN_I2C_RES_DIS, 0);

  SERIAL_PC_PORT.begin(SERIAL_PC_PORT_BAUD);
  //SERIAL_COM_PLUGIN_PORT.begin(SERIAL_COM_PLUGIN_PORT_BAUD);
  SERIAL_FUNC_PLUGIN_PORT.begin(SERIAL_FUNC_PLUGIN_PORT_BAUD);
  strip.begin();
  BUS_I2C.begin();
  PLUGIN_I2C.begin();

  led_set(0x0000FF); // Red

    if (digitalRead(PIN_USB_STAT)) {
    while (!SERIAL_PC_PORT) {
      delay(10);
    }
  }

  SERIAL_PC_PORT.println(INIT_START);
  SERIAL_PC_PORT.println(" ");

  plugin_detection();
  plugin_init();

  if (INIT_MIN_DELAY > millis()) {
    delay(INIT_MIN_DELAY - millis());
  }
  SERIAL_PC_PORT.println(INIT_WORKING);
  SERIAL_PC_PORT.println(" ");

  master0_or_slave1 = master0_or_slave1_detection();

  if (master0_or_slave1) {
  SERIAL_PC_PORT.println(IM_SLAVE);
    module_slave();
  } else {
  SERIAL_PC_PORT.println(IM_MASTER);
    module_detection();
    module_plugin_detection();
  }

  setup_print();

  if (error_code) {
    led_set(0x0000FF); // Red
    SERIAL_PC_PORT.println(" ");
    SERIAL_PC_PORT.println(INIT_FINISH_BAD);
  SERIAL_PC_PORT.println(" ");
  while (1) {
    led_set(0x0000FF); // Red
    delay(1000);
    led_set(0x000000); // Off
    delay(1000);
  }
  } else {
    led_set(0xFF0000); // Blue
    SERIAL_PC_PORT.println(" ");
    SERIAL_PC_PORT.println(INIT_FINISH_OK);
  SERIAL_PC_PORT.println(" ");
  }

  critical_error_check();


  if (master0_or_slave1) {
SERIAL_PC_PORT.println(EXECUTING_SLAVE_MODE);
while (1) {
	az_run();
}
  }


}

void az_run (void) {

  critical_error_check();

  if (millis()%3000<1500) {
    led_set(0xFF0000); // Blue
  } else {
    led_set(0x000000); // Off
  }

  switch (get_com_plugin()) {

    case 1: // RS485 plugin
    ModbusRTUServer.poll();
    break;

  }

  switch (get_func_plugin()) {

    case 3: // Stepper plugin
    stepper.nextAction();
    break;

  }

}